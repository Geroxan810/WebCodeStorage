<?php

require_once( 'vendor/autoload.php' );
// NOTE: Smarty has a capital 'S'
require_once( './vendor/smarty/smarty/libs/Smarty.class.php' );
$smarty = new Smarty();


$id = new basicname\basic(1);
echo $id->returnId();

$smarty->assign('name','Ned');

//** un-comment the following line to show the debug console
//  $smarty->debugging = true;

$smarty->display('index.tpl');