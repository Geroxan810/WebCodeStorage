<?php

namespace basicname;


class basic {

	protected $id;

	public function __construct($id) {
		$this->id = $id;
	}
	public function returnId() {
		return $this->id;
	}
}