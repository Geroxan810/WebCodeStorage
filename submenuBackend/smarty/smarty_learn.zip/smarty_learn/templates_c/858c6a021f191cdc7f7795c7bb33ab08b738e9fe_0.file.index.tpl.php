<?php
/* Smarty version 3.1.31, created on 2017-09-14 23:07:33
  from "C:\xampp\htdocs\smarty_learn\index.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_59bb0bb58d11f8_99107497',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '858c6a021f191cdc7f7795c7bb33ab08b738e9fe' => 
    array (
      0 => 'C:\\xampp\\htdocs\\smarty_learn\\index.tpl',
      1 => 1505430451,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_59bb0bb58d11f8_99107497 (Smarty_Internal_Template $_smarty_tpl) {
echo $_smarty_tpl->tpl_vars['name']->value;
}
}
